# Type d'orientation (Hub Santé) - Hub Santé v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Type d'orientation (Hub Santé)**

## CodeSystem: Type d'orientation (Hub Santé) 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/hubsante/CodeSystem/cs-orientation-type | *Version*:0.1.0 |
| Draft as of 2026-03-17 | *Computable Name*:CSOrientationType |

 
Type d'orientation décidé à l'issue de la régulation médicale. 

 Cette terminologie de référence (CodeSystem) est référencé dans la définition de contenu des jeux de valeurs (ValueSet) suivants : 

* [VSOrientationType](ValueSet-vs-orientation-type.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "cs-orientation-type",
  "url" : "https://interop.esante.gouv.fr/ig/fhir/hubsante/CodeSystem/cs-orientation-type",
  "version" : "0.1.0",
  "name" : "CSOrientationType",
  "title" : "Type d'orientation (Hub Santé)",
  "status" : "draft",
  "date" : "2026-03-17T14:36:04+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Type d'orientation décidé à l'issue de la régulation médicale.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France"
    }]
  }],
  "content" : "complete",
  "count" : 7,
  "concept" : [{
    "code" : "URGENCES",
    "display" : "Urgences"
  },
  {
    "code" : "`REA-USI`",
    "display" : "Réanimation / USI"
  },
  {
    "code" : "SANTE",
    "display" : "Structure de santé"
  },
  {
    "code" : "CABINET",
    "display" : "Cabinet"
  },
  {
    "code" : "DOMICILE",
    "display" : "Domicile"
  },
  {
    "code" : "EPHAD",
    "display" : "EHPAD"
  },
  {
    "code" : "AUTRE",
    "display" : "Autre"
  }]
}

```
